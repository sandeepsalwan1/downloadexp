import sys
import os
import re
import argparse

# Keep track of all the data
entries = {
    "Input Inquiries": 0,
    "Inquiries Added": 0,
    "Inquiries Not Added": 0,
    "Duplicate PIN, SIN, Date, Purpose Type": 0,
    "Invalid Purpose Type": 0,
    "Invalid Date": 0,
    "Pin Equal To Zero": 0,
    "Pin Equal To Blank": 0,
    "Sin Equal To Zero": 0,
    "Sin Equal To Blank": 0,
    "Physical PIN Merge Total": 0,
    "Merged PINs Added": 0,
    "Merged PINs Not Added": 0,
    "Return Code": 0
}
added_purpose_type_entries = {}
start_times = []
end_times = []

def process_file(file, entries, added_purpose_type_entries):
    """
    Discover report files, process them, and update dictionaries
    """
    def add_to_entries(key, value):
        if key in entries:
            entries[key] += int(value)
        else:
            entries[key] = int(value)
      
    def add_to_purpose_entries(key, value):
        if key in added_purpose_type_entries:
            added_purpose_type_entries[key] += int(value)
        else:
            added_purpose_type_entries[key] = int(value)
      
    if not os.path.isfile(file):
        return
      
    try:
        with open(file, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            if not content:
                return
            for line in content.splitlines():
                line = line.strip()
                if line.startswith("Step:"):
                    # Started and Completed
                    start_times.append(line[line.index('Started')+8:line.index('Completed')].strip())
                    end_times.append(line[line.index('Completed')+10:].strip())
                elif line.startswith("Input Inquiries:"):
                    add_to_entries("Input Inquiries", line.split(':')[1].strip())
                elif line.startswith("Inquiries Added:"):
                    add_to_entries("Inquiries Added", line.split(':')[1].strip())
                elif line.startswith("Purpose Type "):
                    add_to_purpose_entries(line.split(':')[0].strip(), line.split(':')[1].strip())
                elif line.startswith("Inquiries Not Added:"):
                    add_to_entries("Inquiries Not Added", line.split(':')[1].strip())
                elif line.startswith("Duplicate PIN, SIN, Date, Purpose Type:"):
                    add_to_entries("Duplicate PIN, SIN, Date, Purpose Type", line.split(':')[1].strip())
                elif line.startswith("Invalid Purpose Type:"):
                    add_to_entries("Invalid Purpose Type", line.split(':')[1].strip())
                elif line.startswith("Invalid Date:"):
                    add_to_entries("Invalid Date", line.split(':')[1].strip())
                elif line.startswith("Pin Equal To Zero:"):
                    add_to_entries("Pin Equal To Zero", line.split(':')[1].strip())
                elif line.startswith("Pin Equal To Blank:"):
                    add_to_entries("Pin Equal To Blank", line.split(':')[1].strip())
                elif line.startswith("Sin Equal To Zero:"):
                    add_to_entries("Sin Equal To Zero", line.split(':')[1].strip())
                elif line.startswith("Sin Equal To Blank:"):
                    add_to_entries("Sin Equal To Blank", line.split(':')[1].strip())
                elif line.startswith("Physical PIN Merge Total:"):
                    add_to_entries("Physical PIN Merge Total", line.split(':')[1].strip())
                elif line.startswith("Merged PINs Added:"):
                    add_to_entries("Merged PINs Added", line.split(':')[1].strip())
                elif line.startswith("Merged PINs Not Added:"):
                    add_to_entries("Merged PINs Not Added", line.split(':')[1].strip())
                elif line.startswith("Return Code:"):
                    entries["Return Code"] = max(entries["Return Code"], int(line.split(':')[1].strip()))
    except UnicodeDecodeError as e:
        print(f"Error decoding file {file}: {e}")

def process_files(report_files):
    """
    Process a list of report files
    """
    for report_file in report_files:
        process_file(report_file, entries, added_purpose_type_entries)

def outputMergedReport(merged_file_path, entries, added_purpose_type_entries, fileType="B", workingDir="currTwoFiles"):
    """
    Output the merged report
    """
    with open(merged_file_path, 'w') as file:
        file.write('\nService Inquiry Logging - Job Execution Report\n\n')
        file.write('Input File: ' + entries.get("Input File", "Unknown") + '\n')
        file.write('Input Format: ' + fileType + '\n')
        file.write('Invalid File: ' + workingDir + '/40-invalid\n')
        file.write('Update Mode: 1 - ENABLED\n')
        file.write('Debug Level: 0\n\n')
        file.write('--------------------------------------------------------------------------------\n\n')
        if start_times and end_times:
            file.write('Step: UPDATE   Started: ' + min(start_times) + '   Completed: ' + max(end_times) + '\n')
        file.write('Input Inquiries: ' + str(entries["Input Inquiries"]) + '\n')
        file.write('Inquiries Added: ' + str(entries["Inquiries Added"]) + '\n')
        for key in sorted(added_purpose_type_entries):
            file.write('    ' + key + ': ' + str(added_purpose_type_entries[key]) + '\n')
        file.write('Inquiries Not Added: ' + str(entries["Inquiries Not Added"]) + '\n')
        file.write('    Duplicate PIN, SIN, Date, Purpose Type: ' + str(entries["Duplicate PIN, SIN, Date, Purpose Type"]) + '\n')
        file.write('    Invalid Purpose Type: ' + str(entries["Invalid Purpose Type"]) + '\n')
        file.write('    Invalid Date: ' + str(entries["Invalid Date"]) + '\n')
        file.write('    Pin Equal To Zero: ' + str(entries["Pin Equal To Zero"]) + '\n')
        file.write('    Pin Equal To Blank: ' + str(entries["Pin Equal To Blank"]) + '\n')
        file.write('    Sin Equal To Zero: ' + str(entries["Sin Equal To Zero"]) + '\n')
        file.write('    Sin Equal To Blank: ' + str(entries["Sin Equal To Blank"]) + '\n')
        file.write('Physical PIN Merge Total: ' + str(entries["Physical PIN Merge Total"]) + '\n')
        file.write('    Merged PINs Added: ' + str(entries["Merged PINs Added"]) + '\n')
        file.write('    Merged PINs Not Added: ' + str(entries["Merged PINs Not Added"]) + '\n')
        file.write('Return Code: ' + str(entries["Return Code"]) + '\n')

def discover_report_files(directory):
    """
    Discover report files dynamically
    """
    report_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file == "report":
                report_files.append(os.path.join(root, file))
    return report_files

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Merge report files")
    parser.add_argument("working_dir", help="The directory containing the report files")
    parser.add_argument("output_file", help="The output file for the merged report")
    args = parser.parse_args()

    report_files = discover_report_files(args.working_dir)
    merged_file_path = args.output_file

    process_files(report_files)
    outputMergedReport(merged_file_path, entries, added_purpose_type_entries, fileType="B", workingDir=args.working_dir)
